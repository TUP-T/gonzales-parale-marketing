<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>CSS Sunrise Animation</title>
  
  
  
      <link rel="stylesheet" href="css/rise.css">

  
</head>

<body>
<?php include 'index.html'; ?>

  <div class="container">
  <div class="sky"></div>
  <div class="sea">
  <div class="light"></div></div>

  <div class="sun"></div>
  <div class="bird1"></div>
  <div class="birdr1"></div>
  <div class="bird"></div>
  <div class="birdr"></div>
  <div class="fin">
  <div class="wave"></div></div>
</div>
  
  

</body>

</html>
