<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Sunrise / Moonrise</title>
  
  
  
      <link rel="stylesheet" href="css/sun.css">

  
</head>

<body>

<?php include 'index.html'; ?>

  <div id="sky">
  <div id="stars">
    <div class="star">·</div>
    <div class="star">·</div>
    <div class="star">·</div>
    <div class="star">·</div>
    <div class="star">·</div>
    <div class="star">·</div>
    <div class="star">·</div>
    <div class="star">·</div>
  </div>
    <div id="sun"></div>
    <div id="moon"></div>
    <div id="land">
      <div class="hill"></div>
      <div class="hill"></div>
      <div class="hill"></div>
      <div class="hill"></div>
      <div class="hill"></div>
  </div>
</div>
  
  

</body>

</html>
