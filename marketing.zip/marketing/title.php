<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Animations</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Droid+Sans'>
  <link rel="stylesheet" href="css/title.css">
   
</head>

<body> 
<?php include 'index.html'; ?>
<?php include 'animatebg.php'; ?>
<?php include 'textedit.html'; ?>

 <div class="container">Bachelor of Technology <br>
 in Information Technology </div> 
 
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script  src="js/title.js"></script>

</body>
</html>
